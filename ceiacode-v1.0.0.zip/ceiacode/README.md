# CEIA Code

**CEIA Code** é o orquestrador de desenvolvimento assistido por IA da **BRIA CE — Brasileira Inteligência Artificial do Ceará**, pertencente à **Black Bacora Corporation**.

CLI multiplataforma para Linux, Termux (Android), Windows e macOS. Requer Node.js 18 ou superior. O núcleo usa APIs nativas do Node.js e não possui dependências npm de runtime.

## Instalação

```bash
npm install -g github:USUARIO/ceiacode
```

Substitua `USUARIO` pelo usuário ou organização GitHub que hospeda o repositório.

No Termux:
```bash
pkg update
pkg install nodejs git
npm install -g github:USUARIO/ceiacode
```

## Uso

```bash
ceiacode
ceiacode keys
ceiacode --help
ceiacode --version
```

Na primeira execução, configure uma chave com `ceiacode keys` ou dentro do chat com `/keys`. Escolha provedor e modelo com `/models`.

Comandos internos: `/models`, `/keys`, `/clear`, `/help` e `/exit`.

## Provedores

- Google AI Studio (Gemini REST)
- Groq (API compatível com OpenAI)
- OpenRouter (inclui roteador `openrouter/free` e modelos `:free`)
- OpenAI
- Claude / Anthropic (Messages API)
- GitHub Copilot (endpoint de chat sujeito a autenticação e elegibilidade da conta)
- Microsoft Azure OpenAI (endpoint e deployment configuráveis)

## Agente de terminal

O agente pode listar diretórios, ler arquivos, criar/editar arquivos e executar comandos. **Toda escrita, sobrescrita ou execução de shell exige confirmação explícita**. Os caminhos de arquivo são limitados ao diretório de trabalho atual. Comandos shell são poderosos: revise-os antes de confirmar.

## Segurança das chaves

As configurações ficam em `~/.ceiacode/keys.json`, com permissões restritas quando suportadas pelo sistema operacional. Não compartilhe esse arquivo nem publique suas chaves. O `.gitignore` exclui arquivos temporários, mas nunca coloque credenciais dentro do repositório.

## Observações importantes

- APIs, nomes de modelos, preços, limites e políticas dos provedores mudam. Confira a documentação oficial de cada serviço.
- O acesso ao GitHub Copilot por API pode depender de conta, licença, termos e tokens próprios do GitHub. O projeto não incorpora credenciais OAuth privadas nem promete acesso universal ao endpoint Copilot.
- Azure OpenAI requer o endpoint do recurso e o nome exato do deployment.
- O CEIA Code não contorna autenticação, cobrança, limites ou políticas dos provedores.

## Desenvolvimento

```bash
git clone https://github.com/USUARIO/ceiacode.git
cd ceiacode
npm run check
node bin/ceiacode.js
```

## Licença

MIT.
