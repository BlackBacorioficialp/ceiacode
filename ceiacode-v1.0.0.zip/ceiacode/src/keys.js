import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

export const CONFIG_DIR = path.join(os.homedir(), ".ceiacode");
export const KEYS_FILE = path.join(CONFIG_DIR, "keys.json");

const PROVIDERS = [
  ["google", "Google AI Studio / Gemini"],
  ["groq", "Groq"],
  ["openrouter", "OpenRouter"],
  ["openai", "OpenAI"],
  ["anthropic", "Claude / Anthropic"],
  ["copilot", "GitHub Copilot"],
  ["azure", "Microsoft Copilot / Azure OpenAI"]
];

export async function loadConfig() {
  try {
    const data = JSON.parse(await fs.readFile(KEYS_FILE, "utf8"));
    return { keys: {}, provider: "google", models: {}, endpoints: {}, ...data };
  } catch {
    return { keys: {}, provider: "google", models: {}, endpoints: {} };
  }
}

export async function saveConfig(config) {
  await fs.mkdir(CONFIG_DIR, { recursive: true, mode: 0o700 });
  await fs.writeFile(KEYS_FILE, JSON.stringify(config, null, 2) + "\n", { mode: 0o600 });
  try { await fs.chmod(KEYS_FILE, 0o600); } catch {}
}

export function maskSecret(value) {
  if (!value) return "(não configurada)";
  if (value.length < 9) return "•".repeat(value.length);
  return `${value.slice(0, 4)}${"•".repeat(Math.min(16, value.length - 8))}${value.slice(-4)}`;
}

export async function keysMenu(config) {
  const rl = readline.createInterface({ input, output });
  try {
    console.log("\nCEIA Code — Gerenciador de chaves");
    for (let i = 0; i < PROVIDERS.length; i++) {
      const [id, name] = PROVIDERS[i];
      console.log(`${i + 1}. ${name}: ${maskSecret(config.keys[id])}`);
    }
    console.log("8. Configurar endpoint Azure OpenAI");
    console.log("0. Voltar");
    const choice = (await rl.question("\nSelecione: ")).trim();
    if (choice === "0" || !choice) return config;
    if (choice === "8") {
      config.endpoints.azure = (await rl.question("Endpoint base do Azure OpenAI: ")).trim();
      config.models.azure = (await rl.question("Deployment/modelo (ex.: gpt-4o): ")).trim();
    } else {
      const item = PROVIDERS[Number(choice) - 1];
      if (!item) { console.log("Opção inválida."); return config; }
      const [id, name] = item;
      if (id === "copilot") {
        console.log("O fluxo OAuth do Copilot será iniciado pelo comando /copilot-login no chat.");
        return config;
      }
      const value = await rl.question(`Cole a chave de ${name} (vazio cancela): `);
      if (value.trim()) config.keys[id] = value.trim();
    }
    await saveConfig(config);
    console.log(`Configuração salva em ${KEYS_FILE}`);
    return config;
  } finally { rl.close(); }
}
