const OPENAI_COMPAT = {
  groq: { url: "https://api.groq.com/openai/v1/chat/completions", model: "llama-3.3-70b-versatile" },
  openrouter: { url: "https://openrouter.ai/api/v1/chat/completions", model: "openrouter/free" },
  openai: { url: "https://api.openai.com/v1/chat/completions", model: "gpt-4o" }
};

async function request(url, options) {
  const response = await fetch(url, { ...options, signal: AbortSignal.timeout(120000) });
  const body = await response.text();
  let data;
  try { data = JSON.parse(body); } catch { data = { raw: body }; }
  if (!response.ok) {
    const message = data?.error?.message || data?.message || body || response.statusText;
    throw new Error(`API respondeu HTTP ${response.status}: ${message}`);
  }
  return data;
}

export async function chatWithProvider(provider, config, messages, modelOverride) {
  const key = config.keys?.[provider];
  const model = modelOverride || config.models?.[provider] || defaults[provider];
  if (provider !== "copilot" && !key) throw new Error(`Configure a chave do provedor "${provider}" usando /keys.`);
  if (provider === "google") {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
    const contents = messages.filter(m => m.role !== "system").map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }]
    }));
    const system = messages.find(m => m.role === "system")?.content;
    const data = await request(url, { method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}), contents, generationConfig: { temperature: 0.2 } }) });
    return data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "O modelo não retornou texto.";
  }
  if (provider === "anthropic") {
    const system = messages.find(m => m.role === "system")?.content || "";
    const data = await request("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "content-type": "application/json", "x-api-key": key,
        "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model, max_tokens: 8192, system,
        messages: messages.filter(m => m.role !== "system").map(m => ({ role: m.role, content: m.content })) })
    });
    return data.content?.filter(c => c.type === "text").map(c => c.text).join("\n") || "O modelo não retornou texto.";
  }
  if (provider === "azure") {
    const endpoint = (config.endpoints?.azure || "").replace(/\/+$/, "");
    if (!endpoint) throw new Error("Configure o endpoint Azure em `ceiacode keys`.");
    const url = `${endpoint}/openai/deployments/${encodeURIComponent(model)}/chat/completions?api-version=2024-10-21`;
    const data = await request(url, { method: "POST", headers: { "content-type": "application/json", "api-key": key },
      body: JSON.stringify({ messages, max_tokens: 8192, temperature: 0.2 }) });
    return data.choices?.[0]?.message?.content || "O modelo não retornou texto.";
  }
  if (provider === "copilot") {
    const token = config.keys?.copilot;
    if (!token) throw new Error("GitHub Copilot ainda não autenticado. Configure o token Copilot em ~/.ceiacode/keys.json após concluir o login OAuth. A disponibilidade do endpoint depende da sua conta e dos termos do GitHub.");
    const copilotToken = config.keys?.copilot_session || token;
    const data = await request("https://api.githubcopilot.com/chat/completions", {
      method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${copilotToken}`,
        "editor-version": "vscode/1.95.0", "editor-plugin-version": "copilot-chat/0.26.7",
        "user-agent": "CEIA-Code/1.0.0" },
      body: JSON.stringify({ model, messages, stream: false })
    });
    return data.choices?.[0]?.message?.content || "O modelo não retornou texto.";
  }
  const spec = OPENAI_COMPAT[provider];
  if (!spec) throw new Error(`Provedor não suportado: ${provider}`);
  const headers = { "content-type": "application/json", authorization: `Bearer ${key}` };
  if (provider === "openrouter") {
    headers["HTTP-Referer"] = "https://github.com/";
    headers["X-Title"] = "CEIA Code";
  }
  const data = await request(spec.url, { method: "POST", headers,
    body: JSON.stringify({ model, messages, temperature: 0.2 }) });
  return data.choices?.[0]?.message?.content || "O modelo não retornou texto.";
}

export const defaults = {
  google: "gemini-2.5-flash",
  groq: "llama-3.3-70b-versatile",
  openrouter: "openrouter/free",
  openai: "gpt-4o",
  anthropic: "claude-3-7-sonnet-latest",
  copilot: "gpt-4o",
  azure: "gpt-4o"
};

export const providerNames = {
  google: "Google AI Studio", groq: "Groq", openrouter: "OpenRouter",
  openai: "OpenAI", anthropic: "Claude / Anthropic",
  copilot: "GitHub Copilot", azure: "Microsoft Copilot / Azure OpenAI"
};

export async function beginGitHubDeviceFlow() {
  const data = await request("https://github.com/login/device/code", {
    method: "POST", headers: { accept: "application/json", "content-type": "application/json" },
    body: JSON.stringify({ client_id: "Iv1.b9a5f6c9e7d8a123", scope: "read:user" })
  });
  return data;
}
