import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

const ROOT = process.cwd();
const MAX_READ = 180_000;

function safePath(target = ".") {
  const resolved = path.resolve(ROOT, target);
  if (resolved !== ROOT && !resolved.startsWith(ROOT + path.sep)) {
    throw new Error("Acesso negado: caminho fora do diretório de trabalho.");
  }
  return resolved;
}

async function confirm(question) {
  if (!input.isTTY) throw new Error("Ação bloqueada: confirmação interativa indisponível (stdin não é TTY).");
  const rl = readline.createInterface({ input, output });
  try { return (await rl.question(`${question} [s/N] `)).trim().toLowerCase() === "s"; }
  finally { rl.close(); }
}

export async function listFiles(target = ".") {
  const dir = safePath(target);
  const entries = await fs.readdir(dir, { withFileTypes: true });
  return entries.map(e => `${e.isDirectory() ? "[DIR] " : "[FILE]"} ${e.name}`).join("\n") || "(diretório vazio)";
}

export async function readFileTool(target) {
  const file = safePath(target);
  const stat = await fs.stat(file);
  if (!stat.isFile()) throw new Error("O caminho não é um arquivo.");
  if (stat.size > MAX_READ) throw new Error("Arquivo muito grande para leitura (limite de 180 KB).");
  return await fs.readFile(file, "utf8");
}

export async function writeFileTool(target, content) {
  const file = safePath(target);
  if (await fs.access(file).then(() => true).catch(() => false)) {
    if (!(await confirm(`O arquivo ${target} já existe. Sobrescrever?`))) return "Edição cancelada pelo usuário.";
  } else if (!(await confirm(`Criar ${target}?`))) return "Criação cancelada pelo usuário.";
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, content, "utf8");
  return `Arquivo salvo: ${target}`;
}

export async function runCommand(command) {
  if (!(await confirm(`Executar comando no terminal?\n${command}`))) return "Comando cancelado pelo usuário.";
  return await new Promise((resolve, reject) => {
    const child = spawn(command, { cwd: ROOT, shell: true, stdio: ["inherit", "pipe", "pipe"] });
    let out = "", err = "";
    child.stdout.on("data", d => { const s = d.toString(); out += s; output.write(s); });
    child.stderr.on("data", d => { const s = d.toString(); err += s; output.write(s); });
    child.on("error", reject);
    child.on("close", code => resolve(`Código de saída: ${code}\n${out}\n${err}`));
  });
}

export async function executeTool(name, args = {}) {
  switch (name) {
    case "list_files": return await listFiles(args.path || ".");
    case "read_file": return await readFileTool(args.path);
    case "write_file": return await writeFileTool(args.path, String(args.content ?? ""));
    case "run_command": return await runCommand(String(args.command || ""));
    default: throw new Error(`Ferramenta desconhecida: ${name}`);
  }
}

export const TOOL_GUIDE = `
Você é o agente de programação do CEIA Code. Responda em português.
Você pode solicitar uma ferramenta emitindo EXATAMENTE um bloco:
<tool_call>{"name":"list_files","args":{"path":"."}}</tool_call>
Ferramentas:
- list_files: {"path":"."}
- read_file: {"path":"caminho"}
- write_file: {"path":"caminho","content":"conteúdo integral"}
- run_command: {"command":"comando"}
Use caminhos relativos ao diretório atual. Nunca tente sair dele. Não alegue que executou algo sem receber o resultado.
Peça uma ferramenta por vez. Para respostas normais, não emita bloco de ferramenta.
`;
